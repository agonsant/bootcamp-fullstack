import './App.css';
import ChessBoard from './chess-board';
import DemoUpdate from './demo-update';
import DemoLifeCycle from './demo-lifecycle';

function App() {
  
  return (
    <div className="App">
      {/* <ChessBoard></ChessBoard>
      <ChessBoard></ChessBoard> */}
      {/* <DemoUpdate></DemoUpdate> */}
      <DemoLifeCycle></DemoLifeCycle>
    </div>
  );
}

export default App;
