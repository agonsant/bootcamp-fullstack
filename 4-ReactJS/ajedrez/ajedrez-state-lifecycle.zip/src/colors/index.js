

export const WHITE_COLOR = '#fccc74';
export const BLACK_COLOR = '#573a2e';